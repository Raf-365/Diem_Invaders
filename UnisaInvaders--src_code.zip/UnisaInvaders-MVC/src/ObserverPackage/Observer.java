package ObserverPackage;

import java.util.*;

public interface Observer extends EventListener {

    public void handleCollisionChanged(StateChangement collisionEvent);

}
