package ObserverPackage;

import java.util.ArrayList;
import java.util.EventObject;

public class StateChangement extends EventObject {

    private ArrayList<Integer> state;

    public StateChangement(Object source, ArrayList<Integer> state) {
        super(source);
        this.state = state;
        this.source = source;
    }

    public ArrayList<Integer> getState() {
        return state;
    }

}
