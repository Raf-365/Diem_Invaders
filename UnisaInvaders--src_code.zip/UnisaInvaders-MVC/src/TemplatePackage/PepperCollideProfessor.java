package TemplatePackage;

import View.MainView;
import entities.Entity;


public class PepperCollideProfessor extends Collision {

 

    @Override
    public void handleCollision(MainView view, Entity entity,  Entity entity2) {
        entity.setVisible(false);
        view.addStates(MainView.PEPPER_COLLIDE_PROFESSOR); 
        view.getClip2().play();
        
    }
                                                                
}
