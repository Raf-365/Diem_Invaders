package TemplatePackage;

import Controller.HudController;
import Controller.PlayController;
import View.MainView;
import entities.Bonus;
import entities.Entity;
import entities.Pepper;
import java.awt.Rectangle;

public class PepperCollideBulletBoss extends Collision {

    @Override
    public void handleCollision(MainView view, Entity entity, Entity entity2) {
        
        entity.setVisible(false);
        view.addStates(MainView.PEPPER_COLLIDE_BULLET_BOSS);
        view.getClip5().play();
        
    }

}
