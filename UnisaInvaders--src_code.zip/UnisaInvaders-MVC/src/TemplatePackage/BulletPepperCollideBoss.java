package TemplatePackage;

import View.MainView;
import entities.Entity;

public class BulletPepperCollideBoss extends Collision {

    @Override
    public void handleCollision(MainView view, Entity entity, Entity entity2) {

        if (entity2.isVisible()) {
            entity.setVisible(false);
            view.addStates(MainView.BULLET_PEPPER_COLLIDE_BOSS);
            view.getClip4().play();
        }
    }
}
