package TemplatePackage;


import View.MainView;
import entities.Entity;


public class BulletPepperCollideProfessor extends Collision {

    @Override
    public void handleCollision(MainView view, Entity entity, Entity entity2) {
        
        entity.setVisible(false);
        entity2.setVisible(false);
        view.addStates(MainView.BULLET_PEPPER_COLLIDE_PROFESSOR);
        view.getClip3().play();
       
    }
}
