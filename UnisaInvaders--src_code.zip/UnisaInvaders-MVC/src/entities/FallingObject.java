package entities;

import View.GameFrame;
import java.util.Random;



public abstract class FallingObject extends Entity {
    private boolean checkCollision;
    int y0;
    public static final int FALLING_OBJECT_SPEED = 3,FALLING_OBJECT_SPEED_UPDATE=1 ;
    static int speed;
    
    
   
    public FallingObject(int x, int y, String path) {
        super(x, y, true, path);
        
        
        y0 = y;
        checkCollision = false;
    }

    public boolean getCheckCollision() {
        return this.checkCollision;
    }

    public void setChekCollision(boolean check) {
        this.checkCollision = check;
    }
    
    public static void setSpeed(int speed) {
        FallingObject.speed = speed;
    }
    
    public static int getSpeed(){return speed;}
    
    public static void updateSpeed(){speed+=FALLING_OBJECT_SPEED_UPDATE;}
    
    public int getY0() {return this.y0;}
    
    
    public void move(boolean disappearFlag){
        
        int x,y;

            x = this.getX();
            y = this.getY();
            y += this.getSpeed();
            
            if (y > GameFrame.MAX_Y) {
                if (!disappearFlag) {
                    y = this.getY0();
                    x = generateRandom();
                   
                    this.setX(x);
                    this.setY(y);                    
                    
                } else {
                    this.setVisible(false);
                }
            } else {
                
                this.setY(y);
            }
        
    }
    
    
    private int generateRandom() {
        Random random = new Random();
        return random.nextInt(GameFrame.MAX_X - 160) + 80;
    }

    
    
    
}
