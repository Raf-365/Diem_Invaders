package entities;



public class Bonus extends FallingObject {

   
    public Bonus(int x, int y, String path) {
        super(x, y, path);
    }

}
