package TemplatePackage1;
import entities.Bullet;
import entities.Weapon;

public class UpdateBulletControllerY extends UpdateMovement{
    
    @Override
    public void handleDifferentUpdate (Weapon entity){
        Bullet bullet = (Bullet)entity;
        bullet.move();
    }
}
