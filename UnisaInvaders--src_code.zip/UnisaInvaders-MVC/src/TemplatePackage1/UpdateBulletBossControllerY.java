package TemplatePackage1;

import entities.*;

public class UpdateBulletBossControllerY extends UpdateMovement{
    
    @Override
    public void handleDifferentUpdate (Weapon entity){
        BulletBoss bulletBoss = (BulletBoss)entity;
        bulletBoss.move();
    }
}
