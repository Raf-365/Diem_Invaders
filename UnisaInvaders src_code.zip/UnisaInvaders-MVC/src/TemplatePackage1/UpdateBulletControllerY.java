/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TemplatePackage1;
import entities.Bullet;
import entities.Weapon;

/**
 *
 * @author antno
 */
public class UpdateBulletControllerY extends UpdateMovement{
    @Override
    public void handleDifferentUpdate (Weapon entity){
        //b.setY(bulletsArray.get(i).getY() + Bullet.MISSILE_SPEED);
        Bullet bullet = (Bullet)entity;
        bullet.move();
    }
}
