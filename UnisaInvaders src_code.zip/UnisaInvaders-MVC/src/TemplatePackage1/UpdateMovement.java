/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TemplatePackage1;



import entities.*;
import java.util.ArrayList;

/**
 *
 * @author antno
 */
public abstract class UpdateMovement {
    
      public void checkMovement(ArrayList<Weapon> bulletsArray) {
        Weapon weapon;
        for (int i = 0; i < bulletsArray.size(); i++) {
            weapon = bulletsArray.get(i);
            if (weapon.isVisible() && weapon.getY() > 0) 
                handleDifferentUpdate(weapon);
            else 
                bulletsArray.remove(weapon);
        }
       
    }
      public abstract void handleDifferentUpdate(Weapon entity);
}
